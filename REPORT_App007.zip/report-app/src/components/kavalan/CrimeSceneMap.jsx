export default function CrimeSceneMap({ location }) {
  return (
    <div className="space-y-2">
      <p className="text-xs text-gray-500 text-center">
        Crime Scene Layout / குற்றஞ்சம்பவிட்ட இட வரைபடம்
      </p>
      <div className="flex justify-center">
        <svg viewBox="0 0 400 280" width="100%" style={{ maxWidth: 400 }}
          className="rounded-xl border border-gray-700 bg-[#1a1a2e]">

          {/* Grid lines */}
          {[80,160,240,320].map(x => (
            <line key={x} x1={x} y1={0} x2={x} y2={280}
              stroke="#2a2a4a" strokeWidth="1" />
          ))}
          {[70,140,210].map(y => (
            <line key={y} x1={0} y1={y} x2={400} y2={y}
              stroke="#2a2a4a" strokeWidth="1" />
          ))}

          {/* Road */}
          <rect x="0" y="120" width="400" height="40" fill="#2d3748" />
          <line x1="0" y1="140" x2="400" y2="140"
            stroke="#c9a227" strokeWidth="1.5" strokeDasharray="20,10" />
          <text x="320" y="155" fill="#c9a227" fontSize="9" fontFamily="sans-serif">
            Road / சாலை
          </text>

          {/* Building */}
          <rect x="280" y="30" width="80" height="70" fill="#374151" stroke="#6b7280" strokeWidth="1.5" rx="3" />
          <text x="290" y="55" fill="#9ca3af" fontSize="9" fontFamily="sans-serif">Building</text>
          <rect x="308" y="58" width="12" height="12" fill="#6b7280" />
          <rect x="328" y="58" width="12" height="12" fill="#6b7280" />
          <rect x="308" y="78" width="12" height="12" fill="#6b7280" />
          <rect x="328" y="78" width="12" height="12" fill="#6b7280" />

          {/* Incident marker */}
          <circle cx="160" cy="195" r="14" fill="#ef4444" opacity="0.3" />
          <circle cx="160" cy="195" r="8"  fill="#ef4444" />
          <text x="140" y="220" fill="#ef4444" fontSize="9" fontFamily="sans-serif">Incident</text>
          <text x="135" y="230" fill="#ef4444" fontSize="8" fontFamily="sans-serif">சம்பவ இடம்</text>

          {/* Victim marker */}
          <circle cx="80"  cy="195" r="8"  fill="#3b82f6" />
          <text x="58"  y="220" fill="#3b82f6" fontSize="9" fontFamily="sans-serif">Victim</text>
          <text x="52"  y="230" fill="#3b82f6" fontSize="8" fontFamily="sans-serif">பாதிக்கப்பட்டவர்</text>

          {/* Suspect marker */}
          <circle cx="240" cy="195" r="8"  fill="#f59e0b" />
          <text x="220" y="220" fill="#f59e0b" fontSize="9" fontFamily="sans-serif">Suspect</text>
          <text x="213" y="230" fill="#f59e0b" fontSize="8" fontFamily="sans-serif">சந்தேக நபர்</text>

          {/* Witness marker */}
          <circle cx="80"  cy="80"  r="8"  fill="#10b981" />
          <text x="60"  y="60"  fill="#10b981" fontSize="9" fontFamily="sans-serif">Witness</text>
          <text x="55"  y="70"  fill="#10b981" fontSize="8" fontFamily="sans-serif">சாட்சி</text>

          {/* Escape route arrow */}
          <defs>
            <marker id="arrow" markerWidth="8" markerHeight="8"
              refX="6" refY="3" orient="auto">
              <path d="M0,0 L0,6 L9,3 z" fill="#ef4444" />
            </marker>
          </defs>
          <line x1="240" y1="185" x2="340" y2="100"
            stroke="#ef4444" strokeWidth="2" strokeDasharray="6,4"
            markerEnd="url(#arrow)" />
          <text x="295" y="135" fill="#ef4444" fontSize="8"
            fontFamily="sans-serif" transform="rotate(-40,295,135)">
            Escape Route
          </text>

          {/* Location label */}
          {location && (
            <text x="200" y="270" fill="#6b7280" fontSize="9"
              fontFamily="sans-serif" textAnchor="middle">
              📍 {location}
            </text>
          )}
        </svg>
      </div>
    </div>
  );
}
