import { Check } from "lucide-react";

export default function StepIndicator({ steps, currentStep }) {
  return (
    <div className="flex items-center justify-center mb-8 no-print">
      {steps.map((step, index) => {
        const stepNum = index + 1;
        const isCompleted = stepNum < currentStep;
        const isActive = stepNum === currentStep;

        return (
          <div key={`step-${index}`} className="flex items-center">
            <div className="flex flex-col items-center">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center 
                font-bold text-sm transition-all ${
                  isCompleted ? "bg-green-600 text-white" :
                  isActive    ? "bg-[#0a1628] text-[#c9a227] ring-4 ring-[#c9a227]/30" :
                                "bg-gray-200 text-gray-400"
                }`}>
                {isCompleted ? <Check className="w-4 h-4" /> : stepNum}
              </div>
              <span className={`mt-1 text-xs font-medium text-center max-w-[64px] ${
                isActive    ? "text-[#c9a227]" :
                isCompleted ? "text-green-600" :
                              "text-gray-400"
              }`}>
                {step}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className={`h-1 w-8 sm:w-16 mx-1 mb-5 rounded transition-all ${
                stepNum < currentStep ? "bg-green-500" : "bg-gray-200"
              }`} />
            )}
          </div>
        );
      })}
    </div>
  );
}
