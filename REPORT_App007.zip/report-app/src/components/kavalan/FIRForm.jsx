export default function FIRForm({ data, onChange }) {
  const field = (label, key, multiline = false) => (
    <div className="space-y-1">
      <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
        {label}
      </label>
      {multiline ? (
        <textarea
          rows={3}
          value={data[key] || ""}
          onChange={(e) => onChange({ ...data, [key]: e.target.value })}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
                     focus:outline-none focus:ring-2 focus:ring-[#0a1628] resize-none"
        />
      ) : (
        <input
          type="text"
          value={data[key] || ""}
          onChange={(e) => onChange({ ...data, [key]: e.target.value })}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
                     focus:outline-none focus:ring-2 focus:ring-[#0a1628]"
        />
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="bg-[#0a1628] text-[#c9a227] text-xs font-bold px-4 py-2 rounded-lg uppercase tracking-widest">
        Complainant Details / புகார்தாரர் விவரம்
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {field("Complainant Name", "complainantName")}
        {field("Age", "complainantAge")}
        {field("Address", "complainantAddress")}
        {field("Contact Number", "complainantContact")}
      </div>

      <div className="bg-[#0a1628] text-[#c9a227] text-xs font-bold px-4 py-2 rounded-lg uppercase tracking-widest">
        Incident Details / சம்பவ விவரம்
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {field("Date of Incident", "incidentDate")}
        {field("Time of Incident", "incidentTime")}
        {field("Place of Occurrence", "incidentLocation")}
        {field("Type of Crime / IPC Section", "crimeType")}
      </div>
      {field("Description of Facts", "incidentDescription", true)}

      <div className="bg-[#0a1628] text-[#c9a227] text-xs font-bold px-4 py-2 rounded-lg uppercase tracking-widest">
        Suspect Details / சந்தேக நபர் விவரம்
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {field("Suspect Name (if known)", "suspectName")}
        {field("Suspect Age", "suspectAge")}
        {field("Suspect Gender", "suspectGender")}
        {field("Suspect Height", "suspectHeight")}
        {field("Suspect Build", "suspectBuild")}
        {field("Skin Tone", "suspectSkinTone")}
        {field("Hair", "suspectHair")}
        {field("Clothing", "suspectClothing")}
      </div>
      {field("Other Physical Features", "suspectFeatures", true)}
      {field("Weapons / Evidence Mentioned", "evidence", true)}
      {field("Witness Details (if any)", "witnesses", true)}
    </div>
  );
}
