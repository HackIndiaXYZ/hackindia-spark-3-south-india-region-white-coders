import { useRef } from "react";
import { Download, Printer } from "lucide-react";
import { format } from "date-fns";
import jsPDF from "jspdf";

export default function FIRDocument({ data, firNumber }) {
  const ref = useRef();

  const Row = ({ label, value }) => (
    <tr className="border-b border-gray-200">
      <td className="py-2 px-3 text-xs font-semibold text-gray-600 w-40 bg-gray-50 align-top">
        {label}
      </td>
      <td className="py-2 px-3 text-sm text-gray-800 align-top">
        {value || "—"}
      </td>
    </tr>
  );

  const downloadPDF = () => {
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const margin = 20;
    let y = margin;

    // Header
    doc.setFillColor(10, 22, 40);
    doc.rect(0, 0, 210, 35, "F");
    doc.setTextColor(201, 162, 39);
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text("FIRST INFORMATION REPORT (FIR)", 105, 14, { align: "center" });
    doc.setFontSize(10);
    doc.text("Tamil Nadu Police — REPORT AI System", 105, 22, { align: "center" });
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(9);
    doc.text(`FIR No: ${firNumber}   |   Date: ${format(new Date(), "dd/MM/yyyy HH:mm")}`, 105, 30, { align: "center" });

    y = 45;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(10);

    const addSection = (title) => {
      doc.setFillColor(10, 22, 40);
      doc.rect(margin, y, 170, 7, "F");
      doc.setTextColor(201, 162, 39);
      doc.setFont("helvetica", "bold");
      doc.text(title, margin + 3, y + 5);
      doc.setTextColor(0, 0, 0);
      doc.setFont("helvetica", "normal");
      y += 10;
    };

    const addRow = (label, value) => {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.text(label + ":", margin, y);
      doc.setFont("helvetica", "normal");
      const lines = doc.splitTextToSize(value || "—", 120);
      doc.text(lines, margin + 55, y);
      y += lines.length * 5 + 3;
    };

    addSection("COMPLAINANT DETAILS / புகார்தாரர் விவரம்");
    addRow("Name", data.complainantName);
    addRow("Age", data.complainantAge);
    addRow("Address", data.complainantAddress);
    addRow("Contact", data.complainantContact);
    y += 3;

    addSection("INCIDENT DETAILS / சம்பவ விவரம்");
    addRow("Date", data.incidentDate);
    addRow("Time", data.incidentTime);
    addRow("Location", data.incidentLocation);
    addRow("Crime Type", data.crimeType);
    addRow("Description", data.incidentDescription);
    y += 3;

    addSection("SUSPECT DETAILS / சந்தேக நபர் விவரம்");
    addRow("Name", data.suspectName);
    addRow("Age / Gender", `${data.suspectAge || ""} / ${data.suspectGender || ""}`);
    addRow("Physical Description", `${data.suspectHeight || ""} ${data.suspectBuild || ""} ${data.suspectSkinTone || ""}`);
    addRow("Clothing", data.suspectClothing);
    addRow("Features", data.suspectFeatures);
    y += 3;

    addSection("EVIDENCE & WITNESSES");
    addRow("Evidence", data.evidence);
    addRow("Witnesses", data.witnesses);
    y += 10;

    // Signature area
    doc.setDrawColor(200, 200, 200);
    doc.line(margin, y + 15, margin + 55, y + 15);
    doc.line(130, y + 15, 190, y + 15);
    doc.setFontSize(8);
    doc.text("Complainant Signature", margin, y + 20);
    doc.text("Officer Signature", 130, y + 20);

    doc.save(`FIR_${firNumber}_${data.complainantName || "report"}.pdf`);
  };

  return (
    <div className="space-y-4">
      {/* Action buttons */}
      <div className="flex gap-3 justify-end no-print">
        <button onClick={() => window.print()}
          className="flex items-center gap-2 px-4 py-2 border border-[#0a1628]
                     text-[#0a1628] rounded-lg text-sm font-medium hover:bg-gray-50">
          <Printer className="w-4 h-4" /> Print
        </button>
        <button onClick={downloadPDF}
          className="flex items-center gap-2 px-4 py-2 bg-[#0a1628] text-[#c9a227]
                     rounded-lg text-sm font-bold hover:bg-[#1a2a48]">
          <Download className="w-4 h-4" /> Download PDF
        </button>
      </div>

      {/* FIR Preview */}
      <div ref={ref} className="bg-white border border-gray-300 rounded-xl overflow-hidden shadow">
        {/* Header */}
        <div className="bg-[#0a1628] text-center py-4 px-4">
          <div className="text-[#c9a227] font-black text-lg tracking-widest">
            FIRST INFORMATION REPORT
          </div>
          <div className="text-gray-300 text-xs mt-1">
            Tamil Nadu Police — REPORT AI System
          </div>
          <div className="text-white text-xs mt-1">
            FIR No: <span className="font-bold text-[#c9a227]">{firNumber}</span>
            &nbsp;|&nbsp; Date: {format(new Date(), "dd/MM/yyyy HH:mm")}
          </div>
        </div>

        {/* Table */}
        <table className="w-full">
          <tbody>
            <tr className="bg-[#0a1628]">
              <td colSpan={2} className="py-1 px-3 text-[#c9a227] text-xs font-bold uppercase tracking-widest">
                Complainant Details / புகார்தாரர் விவரம்
              </td>
            </tr>
            <Row label="Name / பெயர்"         value={data.complainantName} />
            <Row label="Age / வயது"            value={data.complainantAge} />
            <Row label="Address / முகவரி"      value={data.complainantAddress} />
            <Row label="Contact / தொடர்பு"    value={data.complainantContact} />

            <tr className="bg-[#0a1628]">
              <td colSpan={2} className="py-1 px-3 text-[#c9a227] text-xs font-bold uppercase tracking-widest">
                Incident Details / சம்பவ விவரம்
              </td>
            </tr>
            <Row label="Date / தேதி"           value={data.incidentDate} />
            <Row label="Time / நேரம்"           value={data.incidentTime} />
            <Row label="Location / இடம்"        value={data.incidentLocation} />
            <Row label="Crime Type / வகை"       value={data.crimeType} />
            <Row label="Description / விளக்கம்" value={data.incidentDescription} />

            <tr className="bg-[#0a1628]">
              <td colSpan={2} className="py-1 px-3 text-[#c9a227] text-xs font-bold uppercase tracking-widest">
                Suspect Details / சந்தேக நபர் விவரம்
              </td>
            </tr>
            <Row label="Name / பெயர்"          value={data.suspectName} />
            <Row label="Age / வயது"             value={data.suspectAge} />
            <Row label="Gender / பாலினம்"       value={data.suspectGender} />
            <Row label="Height / உயரம்"         value={data.suspectHeight} />
            <Row label="Build / உடல்வாகு"       value={data.suspectBuild} />
            <Row label="Clothing / உடை"         value={data.suspectClothing} />
            <Row label="Features / அம்சங்கள்"   value={data.suspectFeatures} />
            <Row label="Evidence / சாட்சியம்"   value={data.evidence} />
            <Row label="Witnesses / சாட்சிகள்"  value={data.witnesses} />
          </tbody>
        </table>

        {/* Signature area */}
        <div className="grid grid-cols-2 gap-8 px-8 py-6 border-t border-gray-200">
          <div className="text-center">
            <div className="border-t border-gray-400 pt-2 mt-8">
              <p className="text-xs text-gray-500">Complainant Signature</p>
              <p className="text-xs text-gray-400">புகார்தாரர் கையொப்பம்</p>
            </div>
          </div>
          <div className="text-center">
            <div className="border-t border-gray-400 pt-2 mt-8">
              <p className="text-xs text-gray-500">Officer Signature & Seal</p>
              <p className="text-xs text-gray-400">அதிகாரி கையொப்பம்</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
