import { useState, useRef } from "react";
import { Mic, MicOff, Loader2, CheckCircle } from "lucide-react";

const LANG_ISO = {
  en: "en", hi: "hi", ta: "ta", bn: "bn", te: "te", mr: "mr",
  gu: "gu", kn: "kn", or: "or", ml: "ml", pa: "pa", as: "as",
  ne: "ne", sa: "sa", ur: "ur", ks: "ur", sd: "ur",
  mai: "hi", kok: "mr", doi: "hi", mni: "bn", brx: "hi", sat: "en",
};

export default function VoiceRecorder({ selectedLang, onTranscript }) {
  const [recording, setRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState(null);
  const mediaRef = useRef(null);
  const chunksRef = useRef([]);

  const startRecording = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = handleStop;
      recorder.start();
      mediaRef.current = recorder;
      setRecording(true);
    } catch {
      setError("Microphone access denied. Please allow microphone permission.");
    }
  };

  const stopRecording = () => {
    mediaRef.current?.stop();
    mediaRef.current?.stream?.getTracks().forEach((t) => t.stop());
    setRecording(false);
  };

  const handleStop = async () => {
    setLoading(true);
    try {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      const formData = new FormData();
      formData.append("file", blob, "recording.webm");
      formData.append("model", "whisper-1");
      formData.append("language", LANG_ISO[selectedLang?.code] || "en");
      formData.append("response_format", "text");

      const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}` },
        body: formData,
      });

      if (!res.ok) throw new Error("Transcription failed");
      const text = await res.text();
      setTranscript(text);
      onTranscript(text);
    } catch (err) {
      setError("Transcription failed. Check your OpenAI API key in .env");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col items-center gap-4">
        {/* Record button */}
        <button
          onClick={recording ? stopRecording : startRecording}
          disabled={loading}
          className={`w-24 h-24 rounded-full flex items-center justify-center 
            shadow-xl transition-all text-white font-bold text-sm
            ${recording ? "bg-red-600 animate-pulse scale-110" :
              loading   ? "bg-gray-400 cursor-not-allowed" :
                          "bg-[#0a1628] hover:bg-[#1a2a48]"}`}
        >
          {loading ? (
            <Loader2 className="w-8 h-8 animate-spin" />
          ) : recording ? (
            <MicOff className="w-8 h-8" />
          ) : (
            <Mic className="w-8 h-8" />
          )}
        </button>

        <p className="text-sm text-gray-600 font-medium">
          {recording ? "🔴 Recording... tap to stop" :
           loading   ? "Processing audio..." :
                       `Tap to record in ${selectedLang?.label || "English"}`}
        </p>

        {/* Language indicator */}
        <div className="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full">
          Language: <span className="font-semibold text-[#0a1628]">
            {selectedLang?.native} ({selectedLang?.label})
          </span>
        </div>
      </div>

      {/* Transcript output */}
      {transcript && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span className="text-sm font-semibold text-green-700">Transcript</span>
          </div>
          <p className={`text-sm text-gray-700 leading-relaxed ${
            selectedLang?.rtl ? "text-right" : ""
          }`} dir={selectedLang?.rtl ? "rtl" : "ltr"}>
            {transcript}
          </p>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}
    </div>
  );
}
