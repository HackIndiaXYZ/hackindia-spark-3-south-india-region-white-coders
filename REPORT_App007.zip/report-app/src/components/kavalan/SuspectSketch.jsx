import { useState, useEffect } from "react";
import { RefreshCw, Download, AlertCircle } from "lucide-react";

function buildPrompt(data) {
  if (!data) return null;
  const parts = [];
  if (data.suspectAge)         parts.push(`${data.suspectAge} year old`);
  if (data.suspectGender)      parts.push(data.suspectGender);
  if (data.suspectBuild)       parts.push(`${data.suspectBuild} build`);
  if (data.suspectHeight)      parts.push(`height ${data.suspectHeight}`);
  if (data.suspectSkinTone)    parts.push(`${data.suspectSkinTone} skin`);
  if (data.suspectHair)        parts.push(`${data.suspectHair} hair`);
  if (data.suspectFacialHair)  parts.push(data.suspectFacialHair);
  if (data.suspectClothing)    parts.push(`wearing ${data.suspectClothing}`);
  if (data.suspectFeatures)    parts.push(data.suspectFeatures);
  if (data.suspectDescription) parts.push(data.suspectDescription);
  if (data.suspectPhysical)    parts.push(data.suspectPhysical);
  if (parts.length === 0) return null;
  return `forensic police composite sketch portrait of a ${parts.join(", ")}, pencil drawing style, black and white, detailed facial features, police sketch artist style, neutral background`;
}

export default function SuspectSketch({ extractedData }) {
  const [url, setUrl]       = useState(null);
  const [loading, setLoad]  = useState(false);
  const [error, setError]   = useState(null);
  const [prompt, setPrompt] = useState(null);

  const generate = async (p) => {
    setLoad(true); setError(null);
    try {
      const encoded = encodeURIComponent(p);
      const seed = Date.now();
      const imgUrl = `https://image.pollinations.ai/prompt/${encoded}?width=512&height=512&seed=${seed}&nologo=true`;
      await new Promise((res, rej) => {
        const img = new Image();
        img.onload = res;
        img.onerror = rej;
        img.src = imgUrl;
        setTimeout(() => rej(new Error("timeout")), 25000);
      });
      setUrl(imgUrl);
    } catch {
      setError("Sketch generation failed. Check internet connection.");
    } finally {
      setLoad(false);
    }
  };

  // Auto-trigger on data change
  useEffect(() => {
    const p = buildPrompt(extractedData);
    if (p) { setPrompt(p); generate(p); }
  }, [extractedData]);

  if (!extractedData) return (
    <div className="flex flex-col items-center py-10 text-gray-400">
      <AlertCircle className="w-10 h-10 mb-2 opacity-40" />
      <p className="font-semibold">No extracted data yet</p>
      <p className="text-sm">Complete the voice recording step first</p>
    </div>
  );

  if (!prompt) return (
    <div className="flex flex-col items-center py-10 text-gray-400 text-center px-4">
      <AlertCircle className="w-10 h-10 mb-2 opacity-40" />
      <p className="font-semibold">No physical description detected</p>
      <p className="text-sm mt-1 max-w-xs">
        Mention suspect's age, height, clothing, hair, or face features in your statement
      </p>
      <p className="text-xs mt-3 text-gray-500 italic bg-gray-50 p-2 rounded max-w-xs">
        Example: "Tall man, 30 years old, red shirt, black short hair, beard"
      </p>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Image display */}
      <div className="flex justify-center">
        {loading && (
          <div className="w-64 h-64 bg-gray-100 rounded-xl border-2 border-dashed border-gray-300
                          flex flex-col items-center justify-center gap-3">
            <RefreshCw className="w-8 h-8 animate-spin text-[#0a1628]" />
            <p className="text-sm text-gray-500">Generating sketch...</p>
            <p className="text-xs text-gray-400">10–20 seconds</p>
          </div>
        )}
        {!loading && url && (
          <img src={url} alt="Suspect Sketch"
            className="max-w-xs w-full rounded-xl border-2 border-gray-300 shadow-lg" />
        )}
        {!loading && error && (
          <div className="w-64 h-64 bg-red-50 rounded-xl border border-red-200
                          flex flex-col items-center justify-center gap-2 p-4 text-center">
            <AlertCircle className="w-8 h-8 text-red-400" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}
      </div>

      {/* Description used */}
      {prompt && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
          <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Description used:</p>
          <p className="text-xs text-gray-600 italic">{prompt}</p>
        </div>
      )}

      {/* Buttons */}
      <div className="flex justify-center gap-3">
        <button onClick={() => prompt && generate(prompt)} disabled={loading}
          className="flex items-center gap-2 px-4 py-2 border border-[#0a1628] 
                     text-[#0a1628] rounded-lg text-sm font-medium hover:bg-gray-50 disabled:opacity-50">
          <RefreshCw className="w-4 h-4" /> Regenerate
        </button>
        {url && (
          <a href={url} download="suspect_sketch.jpg" target="_blank" rel="noreferrer"
            className="flex items-center gap-2 px-4 py-2 bg-[#0a1628] text-[#c9a227] 
                       rounded-lg text-sm font-bold hover:bg-[#1a2a48]">
            <Download className="w-4 h-4" /> Download
          </a>
        )}
      </div>
    </div>
  );
}
