import { useState } from "react";
import { Outlet, Link, useNavigate } from "react-router-dom";
import { Shield, Home, Plus, Clock, Globe } from "lucide-react";

const LANGUAGES = [
  { code: "en", label: "English", native: "English" },
  { code: "hi", label: "Hindi", native: "हिंदी" },
  { code: "ta", label: "Tamil", native: "தமிழ்" },
  { code: "bn", label: "Bengali", native: "বাংলা" },
  { code: "te", label: "Telugu", native: "తెలుగు" },
  { code: "mr", label: "Marathi", native: "मराठी" },
  { code: "gu", label: "Gujarati", native: "ગુજરાતી" },
  { code: "kn", label: "Kannada", native: "ಕನ್ನಡ" },
  { code: "or", label: "Odia", native: "ଓଡ଼ିଆ" },
  { code: "ml", label: "Malayalam", native: "മലയാളം" },
  { code: "pa", label: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { code: "as", label: "Assamese", native: "অসমীয়া" },
  { code: "mai", label: "Maithili", native: "मैथिली" },
  { code: "sa", label: "Sanskrit", native: "संस्कृतम्" },
  { code: "ne", label: "Nepali", native: "नेपाली" },
  { code: "kok", label: "Konkani", native: "कोंकणी" },
  { code: "doi", label: "Dogri", native: "डोगरी" },
  { code: "mni", label: "Manipuri", native: "মৈতৈলোন্" },
  { code: "brx", label: "Bodo", native: "बड़ो" },
  { code: "ur", label: "Urdu", native: "اردو", rtl: true },
  { code: "ks", label: "Kashmiri", native: "کٲشُر", rtl: true },
  { code: "sd", label: "Sindhi", native: "سنڌي", rtl: true },
  { code: "sat", label: "Santali", native: "ᱥᱟᱱᱛᱟᱲᱤ" },
];

// Export so other components can use it
export { LANGUAGES };

export default function Layout() {
  const [selectedLang, setSelectedLang] = useState(LANGUAGES[0]);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Top navbar */}
      <header className="bg-[#0a1628] text-white shadow-lg no-print">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="bg-[#c9a227] p-2 rounded-lg">
              <Shield className="w-5 h-5 text-[#0a1628]" />
            </div>
            <div>
              <div className="font-black text-lg tracking-widest text-white">REPORT</div>
              <div className="text-[10px] text-[#c9a227] tracking-wide leading-none">
                Tamil Nadu Police · AI Crime Reporting
              </div>
            </div>
          </Link>

          {/* Language selector */}
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#c9a227]" />
            <select
              value={selectedLang.code}
              onChange={(e) => {
                const lang = LANGUAGES.find((l) => l.code === e.target.value);
                setSelectedLang(lang);
              }}
              className="bg-[#1a2a48] text-white text-sm rounded px-2 py-1 
                         border border-[#c9a227]/30 focus:outline-none cursor-pointer"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.native} ({l.label})
                </option>
              ))}
            </select>
          </div>

          {/* Nav links */}
          <nav className="hidden sm:flex items-center gap-4">
            <Link to="/" className="flex items-center gap-1 text-sm text-gray-300 hover:text-white">
              <Home className="w-4 h-4" /> Home
            </Link>
            <button
              onClick={() => navigate("/record", { state: { language: selectedLang } })}
              className="flex items-center gap-1 bg-[#c9a227] text-[#0a1628] 
                         text-sm font-bold px-3 py-1.5 rounded hover:bg-yellow-400"
            >
              <Plus className="w-4 h-4" /> New FIR
            </button>
            <Link to="/history" className="flex items-center gap-1 text-sm text-gray-300 hover:text-white">
              <Clock className="w-4 h-4" /> History
            </Link>
          </nav>
        </div>

        {/* Emergency banner */}
        <div className="bg-red-700 text-white text-xs text-center py-1 tracking-wide">
          🚨 Emergency: 100 &nbsp;|&nbsp; Women Helpline: 1091 &nbsp;|&nbsp; Senior Citizens: 1090
        </div>
      </header>

      {/* Page content — pass selectedLang via context or location state */}
      <main className="flex-1">
        <Outlet context={{ selectedLang, setSelectedLang, LANGUAGES }} />
      </main>

      <footer className="bg-[#0a1628] text-gray-500 text-xs text-center py-3 no-print">
        REPORT — Real-time Evidence Processing for Official Record Transcription &nbsp;|&nbsp; Tamil Nadu Police
      </footer>
    </div>
  );
}
