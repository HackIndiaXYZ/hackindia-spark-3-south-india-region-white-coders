import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FileText, Trash2, Plus, Clock, Search } from "lucide-react";
import { getAllFIRs, deleteFIR } from "../entities/FIRReport";
import { format } from "date-fns";

export default function FIRHistory() {
  const navigate = useNavigate();
  const [records, setRecords] = useState([]);
  const [query, setQuery]     = useState("");

  useEffect(() => { setRecords(getAllFIRs()); }, []);

  const handleDelete = (id) => {
    if (!confirm("Delete this FIR record?")) return;
    deleteFIR(id);
    setRecords(getAllFIRs());
  };

  const filtered = records.filter((r) =>
    [r.firNumber, r.complainantName, r.incidentLocation, r.crimeType, r.language]
      .some((v) => v?.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-[#0a1628]">FIR History</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {records.length} record{records.length !== 1 ? "s" : ""} saved locally
          </p>
        </div>
        <button
          onClick={() => navigate("/record")}
          className="flex items-center gap-2 bg-[#c9a227] text-[#0a1628]
                     font-bold px-4 py-2 rounded-xl hover:bg-yellow-400 text-sm"
        >
          <Plus className="w-4 h-4" /> New FIR
        </button>
      </div>

      {/* Search */}
      {records.length > 0 && (
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search by name, location, FIR number..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm
                       focus:outline-none focus:ring-2 focus:ring-[#0a1628]"
          />
        </div>
      )}

      {/* Empty state */}
      {records.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <FileText className="w-14 h-14 mb-4 opacity-30" />
          <p className="font-semibold text-lg">No FIRs filed yet</p>
          <p className="text-sm mt-1">Your submitted FIRs will appear here</p>
          <button
            onClick={() => navigate("/record")}
            className="mt-6 bg-[#0a1628] text-[#c9a227] font-bold px-6 py-2
                       rounded-xl hover:bg-[#1a2a48] text-sm"
          >
            File First FIR
          </button>
        </div>
      )}

      {/* Records list */}
      <div className="space-y-3">
        {filtered.map((r) => (
          <div
            key={r.id}
            className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm
                       hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between gap-4">
              {/* Left */}
              <div className="flex gap-3 items-start">
                <div className="bg-[#0a1628] p-2 rounded-lg mt-0.5">
                  <FileText className="w-4 h-4 text-[#c9a227]" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-black text-[#0a1628] text-sm">
                      FIR #{r.firNumber}
                    </span>
                    {r.language && (
                      <span className="text-xs bg-purple-100 text-purple-700
                                       px-2 py-0.5 rounded-full font-medium">
                        {r.language}
                      </span>
                    )}
                    {r.crimeType && (
                      <span className="text-xs bg-red-100 text-red-700
                                       px-2 py-0.5 rounded-full font-medium">
                        {r.crimeType}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-700 font-medium">
                    {r.complainantName || "Unknown complainant"}
                  </p>
                  <div className="flex items-center gap-3 text-xs text-gray-400 flex-wrap">
                    {r.incidentLocation && (
                      <span>📍 {r.incidentLocation}</span>
                    )}
                    {r.incidentDate && (
                      <span>📅 {r.incidentDate}</span>
                    )}
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Saved {format(new Date(r.createdAt), "dd MMM yyyy, HH:mm")}
                    </span>
                  </div>
                  {r.incidentDescription && (
                    <p className="text-xs text-gray-400 line-clamp-2 max-w-lg mt-1">
                      {r.incidentDescription}
                    </p>
                  )}
                </div>
              </div>

              {/* Right — delete */}
              <button
                onClick={() => handleDelete(r.id)}
                className="text-gray-300 hover:text-red-500 transition-colors shrink-0"
                title="Delete record"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        {filtered.length === 0 && records.length > 0 && (
          <div className="text-center py-10 text-gray-400">
            <p>No records match "<span className="font-semibold">{query}</span>"</p>
          </div>
        )}
      </div>
    </div>
  );
}
