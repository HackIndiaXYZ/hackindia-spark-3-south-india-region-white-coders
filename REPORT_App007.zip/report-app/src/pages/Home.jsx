import { useNavigate, useOutletContext } from "react-router-dom";
import { Mic, FileText, Clock, Shield, Globe, Brush } from "lucide-react";

export default function Home() {
  const navigate = useNavigate();
  const { selectedLang } = useOutletContext();

  const features = [
    { icon: <Mic className="w-6 h-6" />,    color: "bg-blue-100 text-blue-700",   title: "Voice Recording",     desc: "Record in any of India's 22 official languages" },
    { icon: <Globe className="w-6 h-6" />,   color: "bg-purple-100 text-purple-700", title: "22 Languages",       desc: "Full RTL support for Urdu, Kashmiri & Sindhi" },
    { icon: <Brush className="w-6 h-6" />,   color: "bg-red-100 text-red-700",     title: "AI Suspect Sketch",   desc: "Auto-generates forensic composite from voice" },
    { icon: <FileText className="w-6 h-6" />, color: "bg-green-100 text-green-700", title: "FIR PDF Generation", desc: "Tamil Nadu Police format in bilingual output" },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-10 space-y-10">
      {/* Hero */}
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <div className="bg-[#0a1628] p-4 rounded-2xl shadow-xl">
            <Shield className="w-12 h-12 text-[#c9a227]" />
          </div>
        </div>
        <h1 className="text-4xl font-black text-[#0a1628] tracking-tight">REPORT</h1>
        <p className="text-lg text-gray-500 font-medium">
          Real-time Evidence Processing for Official Record Transcription
        </p>
        <p className="text-sm text-gray-400 max-w-md mx-auto">
          Speak your complaint in any Indian language. AI extracts details, 
          generates a suspect sketch, and produces an official FIR — instantly.
        </p>
        <button
          onClick={() => navigate("/record", { state: { language: selectedLang } })}
          className="mt-4 bg-[#c9a227] text-[#0a1628] font-black text-lg px-8 py-3 
                     rounded-xl hover:bg-yellow-400 shadow-lg transition-all hover:scale-105"
        >
          + File New FIR
        </button>
      </div>

      {/* Feature cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {features.map((f, i) => (
          <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 flex gap-4">
            <div className={`${f.color} p-3 rounded-lg h-fit`}>{f.icon}</div>
            <div>
              <h3 className="font-bold text-[#0a1628]">{f.title}</h3>
              <p className="text-sm text-gray-500 mt-0.5">{f.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Steps */}
      <div className="bg-[#0a1628] rounded-2xl p-6 text-white">
        <h2 className="font-black text-[#c9a227] text-center mb-6 tracking-widest uppercase">
          How It Works
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          {["1. Select Language", "2. Record Voice", "3. AI Sketch", "4. Download FIR"].map((s, i) => (
            <div key={i} className="space-y-2">
              <div className="w-10 h-10 bg-[#c9a227] text-[#0a1628] rounded-full 
                              flex items-center justify-center font-black text-lg mx-auto">
                {i + 1}
              </div>
              <p className="text-xs text-gray-300">{s.slice(3)}</p>
            </div>
          ))}
        </div>
      </div>

      {/* History shortcut */}
      <div className="text-center">
        <button onClick={() => navigate("/history")}
          className="flex items-center gap-2 mx-auto text-sm text-gray-500 hover:text-[#0a1628]">
          <Clock className="w-4 h-4" /> View FIR History
        </button>
      </div>
    </div>
  );
}
