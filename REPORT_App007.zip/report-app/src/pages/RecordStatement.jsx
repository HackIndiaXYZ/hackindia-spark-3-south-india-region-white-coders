import { useState } from "react";
import { useOutletContext, useLocation, useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import StepIndicator from "../components/kavalan/StepIndicator";
import VoiceRecorder from "../components/kavalan/VoiceRecorder";
import FIRForm from "../components/kavalan/FIRForm";
import SuspectSketch from "../components/kavalan/SuspectSketch";
import CrimeSceneMap from "../components/kavalan/CrimeSceneMap";
import FIRDocument from "../components/kavalan/FIRDocument";
import { LANGUAGES } from "../Layout";
import { saveFIR } from "../entities/FIRReport";

const STEPS = ["Language", "Record", "Sketch", "Review", "FIR"];
const FIR_NUM = () => `TN${Date.now().toString().slice(-6)}`;

const AI_SYSTEM_PROMPT = `You are an AI assistant for Tamil Nadu Police crime reporting.
Extract structured information from the victim's voice statement transcript.
ALWAYS respond in valid JSON only. No explanation, no markdown, just raw JSON.
Extract these fields (use null if not mentioned):
{
  "complainantName": "",
  "complainantAge": "",
  "complainantAddress": "",
  "complainantContact": "",
  "incidentDate": "",
  "incidentTime": "",
  "incidentLocation": "",
  "crimeType": "",
  "incidentDescription": "",
  "suspectName": "",
  "suspectAge": "",
  "suspectGender": "",
  "suspectHeight": "",
  "suspectBuild": "",
  "suspectSkinTone": "",
  "suspectHair": "",
  "suspectFacialHair": "",
  "suspectClothing": "",
  "suspectFeatures": "",
  "suspectDescription": "",
  "evidence": "",
  "witnesses": ""
}`;

export default function RecordStatement() {
  const { selectedLang: ctxLang, LANGUAGES: langs } = useOutletContext();
  const location = useLocation();
  const navigate = useNavigate();

  const initLang = location.state?.language || ctxLang || LANGUAGES[0];
  const [lang, setLang]             = useState(initLang);
  const [step, setStep]             = useState(1);
  const [transcript, setTranscript] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [firData, setFirData]       = useState({});
  const [firNumber]                 = useState(FIR_NUM());

  // ── Step 1 language cards ──────────────────────────────────────────────────
  const LanguageStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-black text-[#0a1628]">
          Select Language / மொழி தேர்ந்தெடுக்கவும்
        </h2>
        <p className="text-sm text-gray-500 mt-1">
          Choose the language in which the victim will give their statement
        </p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-80 overflow-y-auto pr-1">
        {LANGUAGES.map((l) => (
          <button
            key={l.code}
            onClick={() => setLang(l)}
            className={`border-2 rounded-xl py-4 px-2 text-center transition-all
              ${lang.code === l.code
                ? "border-[#c9a227] bg-[#0a1628] text-white scale-105 shadow-lg"
                : "border-gray-200 bg-white hover:border-[#0a1628]"}`}
          >
            <div className="text-xs text-gray-400 font-semibold">IN</div>
            <div className={`text-xl font-bold mt-0.5 ${lang.code === l.code ? "text-[#c9a227]" : "text-[#0a1628]"}`}>
              {l.native}
            </div>
            <div className="text-xs text-gray-500 mt-0.5">{l.label}</div>
          </button>
        ))}
      </div>
      <div className="flex justify-center">
        <button onClick={() => setStep(2)}
          className="bg-[#c9a227] text-[#0a1628] font-black px-8 py-3 rounded-xl
                     hover:bg-yellow-400 shadow">
          Continue with {lang.label} →
        </button>
      </div>
    </div>
  );

  // ── Step 2 voice recording ─────────────────────────────────────────────────
  const RecordStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-black text-[#0a1628]">Record Statement</h2>
        <p className="text-sm text-gray-500 mt-1">
          Speak clearly in <span className="font-semibold">{lang.native} ({lang.label})</span>
        </p>
      </div>
      <VoiceRecorder selectedLang={lang} onTranscript={(t) => setTranscript(t)} />
      {transcript && (
        <div className="flex justify-center">
          <button onClick={extractDetails}
            disabled={extracting}
            className="flex items-center gap-2 bg-[#0a1628] text-[#c9a227] font-bold
                       px-8 py-3 rounded-xl hover:bg-[#1a2a48] disabled:opacity-60">
            {extracting
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Extracting details...</>
              : "Extract & Continue →"}
          </button>
        </div>
      )}
    </div>
  );

  // ── AI extraction ──────────────────────────────────────────────────────────
  const extractDetails = async () => {
    setExtracting(true);
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages: [
            { role: "system", content: `${AI_SYSTEM_PROMPT}\nRespond in ${lang.label} where applicable.` },
            { role: "user",   content: `Extract crime details from this statement:\n\n${transcript}` },
          ],
          temperature: 0.2,
        }),
      });
      const json = await res.json();
      const raw  = json.choices?.[0]?.message?.content || "{}";
      const clean = raw.replace(/```json|```/g, "").trim();
      setFirData(JSON.parse(clean));
      setStep(3);
    } catch {
      alert("AI extraction failed. Check your OpenAI API key.");
    } finally {
      setExtracting(false);
    }
  };

  // ── Step 3 sketch + scene ──────────────────────────────────────────────────
  const SketchStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-black text-[#0a1628]">
          Suspect Sketch / சந்தேக நபர் ஓவியம்
        </h2>
        <p className="text-sm text-gray-500 mt-1">
          AI-generated composite sketch from extracted description
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
          <h3 className="font-bold text-[#0a1628] mb-3 text-sm uppercase tracking-wide">
            AI Composite Sketch
          </h3>
          <SuspectSketch extractedData={firData} />
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
          <h3 className="font-bold text-[#0a1628] mb-3 text-sm uppercase tracking-wide">
            Crime Scene Layout / குற்றஞ்சம்பவிட்ட இட வரைபடம்
          </h3>
          <CrimeSceneMap location={firData.incidentLocation} />
        </div>
      </div>
      <div className="flex justify-center gap-3">
        <button onClick={() => setStep(2)}
          className="px-6 py-2 border border-gray-300 rounded-xl text-sm hover:bg-gray-50">
          ← Back
        </button>
        <button onClick={() => setStep(4)}
          className="px-8 py-2 bg-[#c9a227] text-[#0a1628] font-bold rounded-xl hover:bg-yellow-400">
          Continue to Review →
        </button>
      </div>
    </div>
  );

  // ── Step 4 review form ─────────────────────────────────────────────────────
  const ReviewStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-black text-[#0a1628]">Review & Edit</h2>
        <p className="text-sm text-gray-500 mt-1">
          Verify AI-extracted details and fill in any missing fields
        </p>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <FIRForm data={firData} onChange={setFirData} />
      </div>
      <div className="flex justify-center gap-3">
        <button onClick={() => setStep(3)}
          className="px-6 py-2 border border-gray-300 rounded-xl text-sm hover:bg-gray-50">
          ← Back
        </button>
        <button onClick={() => { saveFIR({ ...firData, firNumber, language: lang.label }); setStep(5); }}
          className="px-8 py-2 bg-[#0a1628] text-[#c9a227] font-bold rounded-xl hover:bg-[#1a2a48]">
          Generate FIR →
        </button>
      </div>
    </div>
  );

  // ── Step 5 FIR ─────────────────────────────────────────────────────────────
  const FIRStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-black text-[#0a1628]">FIR Generated ✓</h2>
        <p className="text-sm text-gray-500 mt-1">Download or print the official FIR document</p>
      </div>
      <FIRDocument data={firData} firNumber={firNumber} />
      <div className="flex justify-center gap-3">
        <button onClick={() => navigate("/")}
          className="px-6 py-2 border border-gray-300 rounded-xl text-sm hover:bg-gray-50">
          ← Home
        </button>
        <button onClick={() => navigate("/history")}
          className="px-6 py-2 bg-[#0a1628] text-[#c9a227] font-bold rounded-xl hover:bg-[#1a2a48]">
          View History
        </button>
      </div>
    </div>
  );

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <StepIndicator steps={STEPS} currentStep={step} />
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        {step === 1 && <LanguageStep />}
        {step === 2 && <RecordStep />}
        {step === 3 && <SketchStep />}
        {step === 4 && <ReviewStep />}
        {step === 5 && <FIRStep />}
      </div>
    </div>
  );
}
