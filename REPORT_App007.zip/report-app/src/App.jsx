import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Layout";
import Home from "./pages/Home";
import RecordStatement from "./pages/RecordStatement";
import FIRHistory from "./pages/FIRHistory";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/record" element={<RecordStatement />} />
          <Route path="/history" element={<FIRHistory />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
