const KEY = "report_fir_records";

export function saveFIR(fir) {
  const all = getAllFIRs();
  const record = { ...fir, id: Date.now().toString(), createdAt: new Date().toISOString() };
  all.unshift(record);
  localStorage.setItem(KEY, JSON.stringify(all));
  return record;
}

export function getAllFIRs() {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function deleteFIR(id) {
  const all = getAllFIRs().filter((f) => f.id !== id);
  localStorage.setItem(KEY, JSON.stringify(all));
}
